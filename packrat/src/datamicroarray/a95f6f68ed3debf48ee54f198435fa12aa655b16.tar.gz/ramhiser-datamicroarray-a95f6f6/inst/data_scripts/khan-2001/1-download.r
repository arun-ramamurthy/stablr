# J. Khan, J. Wei, M. Ringner, L. Saal, M. Ladanyi, F. Westermann, F. Berthold, M. Schwab,
# C. Antonescu, C. Peterson, and P. Meltzer
# 'Classification and diagnostic prediction of cancers using gene expression profiling
# and artificial neural networks.' Nat Med. 2001; 7:673-679
install.packages("pamr", dep = T)