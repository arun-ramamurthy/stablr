# Downloads the Su et al. (2002) Novartis multi-tissue data set from Bioconductor
source("http://bioconductor.org/biocLite.R")
biocLite("fabiaData")
