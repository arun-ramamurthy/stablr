# Downloads the Sorlie et al. (2001) SRBCT data set
install.packages('hybridHclust', dep = TRUE)
