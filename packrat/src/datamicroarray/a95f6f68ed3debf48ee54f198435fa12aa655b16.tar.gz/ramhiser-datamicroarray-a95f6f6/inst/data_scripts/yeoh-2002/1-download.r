# Downloads the Yeoh et al. (2002) Leukemia Data Set from Bioconductor
source("http://bioconductor.org/biocLite.R")
biocLite("stjudem")
