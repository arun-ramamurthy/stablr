# A number of cancer data sets are on Bioconductor (http://www.bioconductor.org)
source("http://bioconductor.org/biocLite.R")

# Downloads the Alon Colon Cancer Data Set from Bioconductor
biocLite("colonCA")
